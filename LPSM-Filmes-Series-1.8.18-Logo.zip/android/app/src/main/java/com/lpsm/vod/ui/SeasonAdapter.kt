package com.lpsm.vod.ui

import android.graphics.Typeface
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.lpsm.vod.databinding.ItemSeasonBinding
import com.lpsm.vod.model.Season

class SeasonAdapter(
    private val onSelected: (Season) -> Unit,
    private val onDown: (Season) -> Unit
) : RecyclerView.Adapter<SeasonAdapter.VH>() {

    private var items = listOf<Season>()
    private var selected = -1
    private var recycler: RecyclerView? = null

    override fun onAttachedToRecyclerView(recyclerView: RecyclerView) {
        super.onAttachedToRecyclerView(recyclerView)
        recycler = recyclerView
    }

    override fun onDetachedFromRecyclerView(recyclerView: RecyclerView) {
        recycler = null
        super.onDetachedFromRecyclerView(recyclerView)
    }

    fun submit(v: List<Season>) {
        items = v
        selected = if (v.isEmpty()) -1 else 0
        notifyDataSetChanged()
    }

    fun selectedPosition(): Int = selected

    fun select(index: Int, notify: Boolean = true) {
        if (index !in items.indices) return
        val previous = selected
        selected = index
        if (previous != index) {
            if (previous in items.indices) notifyItemChanged(previous, "selection")
            notifyItemChanged(index, "selection")
        }
        if (notify) onSelected(items[index])
    }

    private fun updateSelection(h: VH, position: Int) {
        val isSelected = position == selected
        h.b.root.isSelected = isSelected
        h.b.name.isSelected = isSelected
        h.b.name.setTypeface(null, if (isSelected) Typeface.BOLD else Typeface.NORMAL)
    }

    override fun onBindViewHolder(h: VH, position: Int, payloads: MutableList<Any>) {
        if (payloads.isNotEmpty() && payloads.all { it == "selection" }) updateSelection(h, position)
        else onBindViewHolder(h, position)
    }

    private fun moveFocus(position: Int) {
        if (position !in items.indices) return
        val view = recycler ?: return
        view.scrollToPosition(position)
        view.post {
            if (view.findViewHolderForAdapterPosition(position)?.itemView?.requestFocus() != true) {
                view.postDelayed({
                    if (recycler === view) view.findViewHolderForAdapterPosition(position)?.itemView?.requestFocus()
                }, 80L)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemSeasonBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val season = items[position]
        h.b.name.text = "Temporada ${season.number}"

        updateSelection(h, position)

        // OK seleciona a temporada.
        h.b.root.setOnClickListener {
            select(h.bindingAdapterPosition)
        }

        // Na TV Box, somente mover o foco para outra temporada já troca os episódios,
        // como em apps de streaming para TV.
        h.b.root.onFocusChangeListener = View.OnFocusChangeListener { v, focused ->
            v.animate()
                .scaleX(if (focused) 1.06f else 1f)
                .scaleY(if (focused) 1.06f else 1f)
                .setDuration(100)
                .start()

            if (focused) {
                // O foco pode mudar durante o layout; atualize a lista depois dele.
                h.b.root.post {
                    val p = h.bindingAdapterPosition
                    if (h.b.root.hasFocus() && p != RecyclerView.NO_POSITION && p != selected) select(p)
                }
            }
        }

        // Seta para baixo entra diretamente nos episódios da temporada selecionada.
        val confirm = RemoteConfirm()
        h.b.root.setOnKeyListener { _, keyCode, event ->
            if (confirm.handle(h.b.root, keyCode, event)) return@setOnKeyListener true
            if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT || keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) {
                if (event.action == KeyEvent.ACTION_DOWN) {
                    val p = h.bindingAdapterPosition
                    if (p != RecyclerView.NO_POSITION) {
                        moveFocus(p + if (keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) 1 else -1)
                    }
                }
                return@setOnKeyListener true
            }
            if (event.action == KeyEvent.ACTION_DOWN && keyCode == KeyEvent.KEYCODE_DPAD_DOWN) {
                val p = h.bindingAdapterPosition
                if (p != RecyclerView.NO_POSITION) {
                    if (event.repeatCount == 0) {
                        if (p != selected) select(p)
                        onDown(items[p])
                    }
                    true
                } else {
                    false
                }
            } else {
                false
            }
        }
    }

    class VH(val b: ItemSeasonBinding) : RecyclerView.ViewHolder(b.root)
}
